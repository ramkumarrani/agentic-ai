"""
Simple test script to verify the installation and basic functionality.
"""
import sys
import os


def test_imports():
    """Test that all required packages can be imported."""
    print("Testing imports...")
    
    try:
        import langchain
        print("✓ langchain")
    except ImportError:
        print("✗ langchain - FAILED")
        return False
    
    try:
        import langgraph
        print("✓ langgraph")
    except ImportError:
        print("✗ langgraph - FAILED")
        return False
    
    try:
        import langchain_openai
        print("✓ langchain_openai")
    except ImportError:
        print("✗ langchain_openai - FAILED")
        return False
    
    try:
        from dotenv import load_dotenv
        print("✓ python-dotenv")
    except ImportError:
        print("✗ python-dotenv - FAILED")
        return False
    
    try:
        import pydantic
        print("✓ pydantic")
    except ImportError:
        print("✗ pydantic - FAILED")
        return False
    
    return True


def test_project_structure():
    """Test that the project structure is correct."""
    print("\nTesting project structure...")
    
    required_files = [
        "src/agents/clarity_agent.py",
        "src/agents/research_agent.py",
        "src/agents/validator_agent.py",
        "src/agents/synthesis_agent.py",
        "src/graph/research_graph.py",
        "src/models/state.py",
        "src/utils/config.py",
        "src/utils/mock_data.py",
        "main.py",
        "requirements.txt",
        ".env.example",
    ]
    
    all_exist = True
    for file_path in required_files:
        if os.path.exists(file_path):
            print(f"✓ {file_path}")
        else:
            print(f"✗ {file_path} - MISSING")
            all_exist = False
    
    return all_exist


def test_env_configuration():
    """Test environment configuration."""
    print("\nTesting environment configuration...")
    
    if not os.path.exists(".env"):
        print("⚠️  .env file not found")
        print("   Run: copy .env.example .env  (Windows)")
        print("   or:  cp .env.example .env    (macOS/Linux)")
        print("   Then add your OPENAI_API_KEY")
        return False
    
    from dotenv import load_dotenv
    load_dotenv()
    
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key or api_key == "your_openai_api_key_here":
        print("✗ OPENAI_API_KEY not configured")
        print("   Edit .env and add your actual OpenAI API key")
        return False
    
    print("✓ OPENAI_API_KEY configured")
    
    tavily_key = os.getenv("TAVILY_API_KEY")
    if tavily_key and tavily_key != "your_tavily_api_key_here":
        print("✓ TAVILY_API_KEY configured (optional)")
    else:
        print("ℹ  TAVILY_API_KEY not configured (will use mock data)")
    
    return True


def test_basic_functionality():
    """Test basic functionality."""
    print("\nTesting basic functionality...")
    
    try:
        from src.utils.mock_data import get_mock_research
        
        data = get_mock_research("Apple")
        if data:
            print("✓ Mock data retrieval works")
        else:
            print("✗ Mock data retrieval failed")
            return False
        
        from src.models.state import AgentState
        print("✓ State schema imports correctly")
        
        from src.agents import ClarityAgent, ResearchAgent, ValidatorAgent, SynthesisAgent
        print("✓ All agents import correctly")
        
        from src.graph import ResearchAssistantGraph
        print("✓ Graph imports correctly")
        
        return True
    
    except Exception as e:
        print(f"✗ Error: {e}")
        return False


def main():
    """Run all tests."""
    print("=" * 70)
    print("Multi-Agent Research Assistant - Installation Test")
    print("=" * 70)
    
    tests = [
        ("Package Imports", test_imports),
        ("Project Structure", test_project_structure),
        ("Environment Configuration", test_env_configuration),
        ("Basic Functionality", test_basic_functionality),
    ]
    
    results = []
    for name, test_func in tests:
        try:
            result = test_func()
            results.append((name, result))
        except Exception as e:
            print(f"\n✗ {name} failed with error: {e}")
            results.append((name, False))
    
    print("\n" + "=" * 70)
    print("TEST SUMMARY")
    print("=" * 70)
    
    for name, result in results:
        status = "PASSED ✓" if result else "FAILED ✗"
        print(f"{name}: {status}")
    
    all_passed = all(result for _, result in results)
    
    if all_passed:
        print("\n🎉 All tests passed! The system is ready to use.")
        print("\nNext steps:")
        print("1. Run the CLI: python main.py")
        print("2. Try examples: python -m examples.example_1_basic")
    else:
        print("\n⚠️  Some tests failed. Please fix the issues above.")
        return 1
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
