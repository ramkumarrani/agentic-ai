# Visual Guide

## 🎨 System Flow Diagrams

### Complete Agent Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                         USER QUERY                              │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         ▼
              ┌──────────────────────┐
              │   CLARITY AGENT      │
              │                      │
              │ • Parse query        │
              │ • Extract company    │
              │ • Check specificity  │
              └──────────┬───────────┘
                         │
          ┌──────────────┴──────────────┐
          │                             │
    [CLEAR]                     [NEEDS CLARIFICATION]
          │                             │
          │                             ▼
          │                   ┌──────────────────────┐
          │                   │     🚦 INTERRUPT     │
          │                   │                      │
          │                   │ • Pause workflow     │
          │                   │ • Request details    │
          │                   │ • Wait for user      │
          │                   └──────────┬───────────┘
          │                             │
          │                    [User Clarifies]
          │                             │
          └─────────────┬───────────────┘
                        │
                        ▼
              ┌──────────────────────┐
              │   RESEARCH AGENT     │
              │                      │
              │ • Search Tavily-MCP/ |
              |             Mock     │
              │ • Gather information │
              │ • Score confidence   │
              └──────────┬───────────┘
                         │
          ┌──────────────┴──────────────┐
          │                             │
   [Confidence ≥ 6]            [Confidence < 6]
          │                             │
          │                             ▼
          │                   ┌──────────────────────┐
          │                   │  VALIDATOR AGENT     │
          │                   │                      │
          │                   │ • Check quality      │
          │                   │ • Assess gaps        │
          │                   │ • Increment attempts │
          │                   └──────────┬───────────┘
          │                             │
          │              ┌──────────────┴─────────────┐
          │              │                            │
          │        [SUFFICIENT]              [INSUFFICIENT]
          │              │                            │
          │              │                   ┌────────┴────────┐
          │              │                   │                 │
          │              │           [Attempts < 3]    [Attempts = 3]
          │              │                   │                 │
          │              │          [Loop to Research]         │
          │              │                   │                 │
          │              │                   └─────────────────┤
          │              │                                     │
          └──────────────┴─────────────────────────────────────┘
                         │
                         ▼
              ┌──────────────────────┐
              │  SYNTHESIS AGENT     │
              │                      │
              │ • Format response    │
              │ • Add context        │
              │ • User-friendly      │
              └──────────┬───────────┘
                         │
                         ▼
              ┌──────────────────────┐
              │    FINAL RESPONSE    │
              │     (to user)        │
              └──────────────────────┘
```

---

## 🔄 Agent Interaction Patterns

### Pattern 1: Happy Path (Clear Query, High Confidence)
```
User Query: "Tell me about Apple"
    ↓
Clarity Agent: ✓ Clear (company = "Apple")
    ↓
Research Agent: ✓ Found info (confidence = 8/10)
    ↓
Synthesis Agent: ✓ Created response
    ↓
User: [Receives comprehensive answer]
```

### Pattern 2: Interrupt Path (Unclear Query)
```
User Query: "What's the stock price?"
    ↓
Clarity Agent: ✗ Unclear (no company mentioned)
    ↓
INTERRUPT: "Which company?"
    ↓
User Clarification: "Tesla"
    ↓
Clarity Agent: ✓ Clear (company = "Tesla")
    ↓
Research Agent: ✓ Found info
    ↓
Synthesis Agent: ✓ Created response
```

### Pattern 3: Validation Loop (Low Confidence)
```
User Query: "Tell me about Netflix gaming"
    ↓
Clarity Agent: ✓ Clear (company = "Netflix")
    ↓
Research Agent: ⚠ Found limited info (confidence = 4/10)
    ↓
Validator Agent: ✗ Insufficient (attempt 1)
    ↓
Research Agent: ⚠ Found more (confidence = 5/10)
    ↓
Validator Agent: ✗ Insufficient (attempt 2)
    ↓
Research Agent: ⚠ Found more (confidence = 6/10)
    ↓
Validator Agent: ✓ Sufficient (attempt 3, forced)
    ↓
Synthesis Agent: ✓ Created response
```

### Pattern 4: Multi-Turn Conversation
```
Turn 1:
User: "Tell me about Microsoft"
System: [Provides Microsoft overview]

Turn 2:
User: "What about their CEO?"  ← Context: Still Microsoft
System: [Provides CEO info for Microsoft]

Turn 3:
User: "And their cloud business?"  ← Context: Still Microsoft
System: [Provides Azure info]
```

---

## 📊 State Evolution Example

### Initial State
```python
{
    "messages": [],
    "query": "What's the stock price?",
    "company_name": "",
    "clarity_status": "needs_clarification",
    "research_findings": {},
    "confidence_score": 0.0,
    "validation_result": "insufficient",
    "validation_attempts": 0,
    "final_response": "",
    "next_action": ""
}
```

### After Clarity Agent (Unclear)
```python
{
    "messages": [AIMessage("I need clarification: Which company?")],
    "query": "What's the stock price?",
    "company_name": "UNKNOWN",
    "clarity_status": "needs_clarification",  ← Set by Clarity
    ...
}
```

### After User Clarification
```python
{
    "messages": [
        AIMessage("I need clarification: Which company?"),
        HumanMessage("Tesla")  ← Added by user
    ],
    "query": "Tesla",  ← Updated
    ...
}
```

### After Clarity Agent (Clear)
```python
{
    "messages": [..., AIMessage("Researching Tesla...")],
    "query": "Tesla",
    "company_name": "Tesla",  ← Extracted
    "clarity_status": "clear",  ← Updated
    ...
}
```

### After Research Agent
```python
{
    "messages": [...],
    "company_name": "Tesla",
    "research_findings": {  ← Added
        "source": "mock",
        "data": {...}
    },
    "confidence_score": 7.0,  ← Scored
    ...
}
```

### After Synthesis Agent (Final)
```python
{
    "messages": [..., AIMessage("Here's what I found...")],
    "company_name": "Tesla",
    "research_findings": {...},
    "confidence_score": 7.0,
    "final_response": "Tesla is...",  ← Created
    ...
}
```

---

## 🎯 Routing Decision Tree

```
START
  │
  ├─→ Clarity Agent
  │     │
  │     ├─→ [clarity_status = "clear"]
  │     │     └─→ Research Agent
  │     │
  │     └─→ [clarity_status = "needs_clarification"]
  │           └─→ INTERRUPT → Wait → User Input → Clarity Agent
  │
  └─→ Research Agent
        │
        ├─→ [confidence_score ≥ 6]
        │     └─→ Synthesis Agent → END
        │
        └─→ [confidence_score < 6]
              └─→ Validator Agent
                    │
                    ├─→ [validation_result = "sufficient"]
                    │     └─→ Synthesis Agent → END
                    │
                    └─→ [validation_result = "insufficient"]
                          │
                          ├─→ [validation_attempts < 3]
                          │     └─→ Research Agent (loop)
                          │
                          └─→ [validation_attempts ≥ 3]
                                └─→ Synthesis Agent → END (forced)
```

---

## 🏗️ Component Relationships

```
┌────────────────────────────────────────────────────────────┐
│                    USER INTERFACE                          │
│  (main.py, examples/*.py)                                  │
└─────────────────┬──────────────────────────────────────────┘
                  │
                  ▼
┌────────────────────────────────────────────────────────────┐
│               LANGGRAPH ORCHESTRATOR                       │
│  (src/graph/research_graph.py)                            │
│                                                            │
│  • StateGraph with 5 nodes                                │
│  • 3 conditional routing functions                        │
│  • MemorySaver for persistence                           │
│  • Interrupt management                                   │
└───┬──────────────┬──────────────┬──────────────┬──────────┘
    │              │              │              │
    ▼              ▼              ▼              ▼
┌─────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐
│ Clarity │  │ Research │  │Validator │  │Synthesis │
│  Agent  │  │  Agent   │  │  Agent   │  │  Agent   │
└────┬────┘  └────┬─────┘  └────┬─────┘  └────┬─────┘
     │            │             │             │
     └────────────┴─────────────┴─────────────┘
                  │
                  ▼
     ┌────────────────────────────┐
     │      SHARED RESOURCES      │
     │                            │
     │  • BaseAgent (common)      │
     │  • AgentState (schema)     │
     │  • Config (settings)       │
     │  • Mock Data (fallback)    │
     └────────────────────────────┘
```

---

## 💬 Conversation Flow Example

```
SESSION: thread_123
─────────────────────────────────────────

[Turn 1]
👤 User: Tell me about Apple
🤖 System Processing:
   1. Clarity Agent → Clear (company: Apple)
   2. Research Agent → Found data (confidence: 8/10)
   3. Synthesis Agent → Creating response
💬 Response: "Apple Inc. is a technology company..."

STATE: {
  messages: [Human("Tell me..."), AI("Apple Inc...")],
  company_name: "Apple",
  ...
}

─────────────────────────────────────────

[Turn 2]
👤 User: What about their CEO?
🤖 System Processing:
   1. Clarity Agent → Clear (context: still Apple)
   2. Research Agent → Found CEO data
   3. Synthesis Agent → Creating response
💬 Response: "Tim Cook is the CEO of Apple..."

STATE: {
  messages: [
    Human("Tell me..."), AI("Apple Inc..."),
    Human("What about CEO?"), AI("Tim Cook...")
  ],
  company_name: "Apple",  ← Maintained
  ...
}

─────────────────────────────────────────

[Turn 3]
👤 User: Now tell me about Tesla
🤖 System Processing:
   1. Clarity Agent → Clear (new company: Tesla)
   2. Research Agent → Found Tesla data
   3. Synthesis Agent → Creating response
💬 Response: "Tesla is an electric vehicle company..."

STATE: {
  messages: [...previous..., 
    Human("Now tell me..."), AI("Tesla is...")
  ],
  company_name: "Tesla",  ← Updated
  ...
}
```

---

## 🎓 Key Concepts Illustrated

### 1. Agent Specialization
```
Each agent has ONE clear job:
• Clarity  → Is query clear?
• Research → Find information
• Validator→ Is info good enough?
• Synthesis→ Make it readable
```

### 2. Conditional Routing
```
Not all queries take the same path:
• High confidence → Skip validation
• Low confidence → Validate first
• Unclear query → Ask user first
```

### 3. Feedback Loops
```
Research ←→ Validator
   ↓
Limited attempts (max 3)
   ↓
Prevents infinite loops
```

### 4. State Persistence
```
State flows through all agents:
Agent 1 → Updates state → Agent 2 → Updates state → ...
                ↓
         Saved in MemorySaver
                ↓
    Available for next query
```

### 5. Human-in-the-Loop
```
Normal Flow: Agent → Agent → Agent → End
                ↓
Interrupt Flow: Agent → 🚦 Wait → User → Agent → ...
```

---

## 🎯 Success Indicators

When the system is working correctly, you'll see:

✅ **Clarity Agent**: Correctly identifies clear vs unclear queries  
✅ **Research Agent**: Finds relevant information  
✅ **Validator Agent**: Provides thoughtful assessment  
✅ **Synthesis Agent**: Creates readable responses  
✅ **Routing**: Takes appropriate paths based on state  
✅ **Interrupts**: Pauses and resumes smoothly  
✅ **Context**: Remembers previous conversation  
✅ **Loops**: Limits attempts and resolves eventually

---

This visual guide helps understand:
- How agents collaborate
- How state evolves
- How routing decisions are made
- How conversations flow
- How the system handles different scenarios

Refer to this when exploring the code or running examples!
