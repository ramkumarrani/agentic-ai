# Quick Start Guide

## 🚀 Get Started in 3 Minutes

### 1. Install Dependencies
```bash
# Create virtual environment (recommended)
python -m venv venv

# Activate it
venv\Scripts\activate  # Windows
# or
source venv/bin/activate  # macOS/Linux

# Install packages
pip install -r requirements.txt
```

### 2. Configure API Key
```bash
# Copy template
copy .env.example .env  # Windows
# or
cp .env.example .env  # macOS/Linux

# Edit .env and add your OpenAI API key
# OPENAI_API_KEY=sk-...
```

### 3. Test Installation
```bash
python test_setup.py
```

If all tests pass, you're ready! ✓

## 🎮 Usage Options

### Interactive CLI
Best for: Exploring the system interactively
```bash
python main.py
```

### Run All Examples
Best for: Seeing all features demonstrated
```bash
python run_examples.py
```

### Individual Examples
Best for: Understanding specific features

```bash
# Basic conversation with follow-ups
python -m examples.example_1_basic

# Human-in-the-loop clarification
python -m examples.example_2_interrupt

# Validation feedback loop
python -m examples.example_3_validation

# Comprehensive demonstration
python -m examples.example_4_comprehensive
```

## 💡 Quick Tips

### Multi-Turn Conversations
The system remembers context across queries:
```
You: "Tell me about Apple"
Assistant: [Provides Apple info]

You: "What about their CEO?"  # Remembers we're talking about Apple
Assistant: [Provides CEO info]
```

### Handling Unclear Queries
If you're vague, the system will ask for clarification:
```
You: "What's the stock price?"
Assistant: "Which company are you asking about?"
You: "Tesla"
Assistant: [Provides Tesla stock info]
```

### Available Companies (Mock Data)
- Apple Inc. / Apple
- Tesla
- Microsoft
- Google
- Amazon
- Netflix
- Meta

Add Tavily API key for real-time data on any company!

## 🏗️ Architecture Overview

```
Query → Clarity → Research → Validator → Synthesis → Response
           ↓                      ↓
      (Interrupt)           (Feedback Loop)
```

**4 Agents:**
1. **Clarity**: Is the query clear?
2. **Research**: Gather information
3. **Validator**: Is info sufficient?
4. **Synthesis**: Create response

**3 Routing Points:**
- After Clarity: Clear → Research, Unclear → Interrupt
- After Research: High confidence → Synthesis, Low → Validator
- After Validator: Sufficient → Synthesis, Insufficient → Research (loop)

## 📝 Common Commands

```bash
# Test setup
python test_setup.py

# Interactive CLI
python main.py

# Run all examples
python run_examples.py

# Individual example
python -m examples.example_1_basic

# Install new dependency
pip install package_name

# Update requirements
pip freeze > requirements.txt
```

## 🐛 Troubleshooting

**"OPENAI_API_KEY not found"**
→ Create .env file and add your API key

**Import errors**
→ Activate virtual environment first

**"No module named 'src'"**
→ Run from project root directory

**Need help?**
→ Check README.md for detailed documentation

## 🎯 What's Next?

1. Try the interactive CLI
2. Run the examples to understand features
3. Modify example scripts for your needs
4. Add more companies to mock_data.py
5. Integrate Tavily for real-time search

Enjoy building with multi-agent systems! 🚀
