# Multi-Agent Research Assistant with LangGraph

A sophisticated multi-agent system built with LangGraph that helps users gather comprehensive information about companies. The system features four specialized agents working together with human-in-the-loop capabilities, conditional routing, and multi-turn conversation support.

## 🎯 Overview

This research assistant uses a multi-agent architecture to:
- Analyze query clarity and request clarification when needed
- Gather comprehensive company information from multiple sources
- Validate research quality with feedback loops
- Synthesize findings into coherent, user-friendly responses
- Maintain conversation context across multiple turns

## 🏗️ Architecture

### Agent System

```
┌─────────────────────────────────────────────────────────────┐
│                    User Query                                │
└──────────────────┬──────────────────────────────────────────┘
                   │
                   ▼
         ┌─────────────────┐
         │ Clarity Agent   │◄──── Checks query clarity
         │                 │      Extracts company name
         └────────┬────────┘
                  │
          ┌───────┴───────┐
          │               │
      [Clear]      [Needs Clarification]
          │               │
          │               ▼
          │      ┌─────────────────┐
          │      │    INTERRUPT    │◄──── Human-in-the-loop
          │      │  (Wait for user)│      Request clarification
          │      └────────┬────────┘
          │               │
          │      [User provides clarification]
          │               │
          └───────┬───────┘
                  │
                  ▼
         ┌─────────────────┐
         │ Research Agent  │◄──── Gathers company info
         │                 │      Assigns confidence score
         └────────┬────────┘
                  │
          ┌───────┴────────┐
          │                │
    [Confidence ≥ 6]  [Confidence < 6]
          │                │
          │                ▼
          │       ┌─────────────────┐
          │       │ Validator Agent │◄──── Validates research
          │       │                 │      Checks completeness
          │       └────────┬────────┘
          │                │
          │         ┌──────┴──────┐
          │         │             │
          │   [Sufficient]  [Insufficient]
          │         │             │
          │         │      [Attempts < 3]
          │         │             │
          │         │        [Loop back to Research]
          │         │             │
          └─────────┴─────────────┘
                    │
                    ▼
         ┌─────────────────┐
         │ Synthesis Agent │◄──── Creates final response
         │                 │      Formats user-friendly output
         └────────┬────────┘
                  │
                  ▼
            ┌──────────┐
            │   END    │
            └──────────┘
```

### State Management

The system uses a comprehensive state schema that tracks:
- **Conversation history**: All messages for context
- **Query details**: Current query and extracted company name
- **Agent outputs**: Research findings, confidence scores, validation results
- **Flow control**: Routing decisions and attempt counters
- **Final response**: Synthesized answer for the user

### Conditional Routing

Three key routing functions control the flow:

1. **After Clarity Agent**: Routes to Research (if clear) or Interrupt (if needs clarification)
2. **After Research Agent**: Routes to Validator (if confidence < 6) or Synthesis (if confidence ≥ 6)
3. **After Validator Agent**: Routes to Research (if insufficient and attempts < 3) or Synthesis (otherwise)

## 🚀 Setup & Installation

### Prerequisites

- Python 3.9 or higher
- OpenAI API key (required)
- Tavily API key (optional - will use mock data if not provided)

### Installation Steps

1. **Clone or extract the repository**

2. **Create a virtual environment** (recommended)
```bash
python -m venv venv

# Windows
venv\Scripts\activate

# macOS/Linux
source venv/bin/activate
```

3. **Install dependencies**
```bash
pip install -r requirements.txt
```

4. **Configure environment variables**
```bash
# Copy the example file
copy .env.example .env  # Windows
cp .env.example .env    # macOS/Linux

# Edit .env and add your API keys
OPENAI_API_KEY=your_actual_openai_key_here
TAVILY_API_KEY=your_tavily_key_here  # Optional
```

## 💻 Usage

### Option 1: Interactive CLI

Run the main CLI interface for an interactive conversation:

```bash
python main.py
```

Example interaction:
```
🧑 You: What's the stock price?

🤖 Assistant: I need clarification to proceed.
   I need clarification: Which company are you asking about?

🧑 Your clarification: Apple

🤖 Assistant: [Research results about Apple's stock...]
```

### Option 2: Example Scripts

Run pre-built examples demonstrating specific features:

**Example 1: Basic multi-turn conversation**
```bash
python -m examples.example_1_basic
```

**Example 2: Human-in-the-loop with interrupts**
```bash
python -m examples.example_2_interrupt
```

**Example 3: Validation feedback loop**
```bash
python -m examples.example_3_validation
```

**Example 4: Comprehensive demonstration**
```bash
python -m examples.example_4_comprehensive
```

### Option 3: Programmatic Usage

```python
from src.graph import ResearchAssistantGraph
from src.utils.config import Config

# Validate configuration
Config.validate()

# Initialize the assistant
assistant = ResearchAssistantGraph()

# Create a conversation session
config = {"configurable": {"thread_id": "my_session"}}

# Query 1
result1 = assistant.invoke("Tell me about Tesla", config)
print(result1['final_response'])

# Query 2 (maintains context from Query 1)
result2 = assistant.invoke("What about their CEO?", config)
print(result2['final_response'])
```

## 📁 Project Structure

```
turing-new/
├── src/
│   ├── agents/
│   │   ├── __init__.py
│   │   ├── base.py              # Base agent class with common functionality
│   │   ├── clarity_agent.py     # Analyzes query clarity
│   │   ├── research_agent.py    # Gathers company information
│   │   ├── validator_agent.py   # Validates research quality
│   │   └── synthesis_agent.py   # Creates final responses
│   ├── graph/
│   │   ├── __init__.py
│   │   └── research_graph.py    # LangGraph implementation with routing
│   ├── models/
│   │   ├── __init__.py
│   │   └── state.py             # State schema definition
│   ├── utils/
│   │   ├── __init__.py
│   │   ├── config.py            # Configuration management
│   │   └── mock_data.py         # Mock company data
│   └── __init__.py
├── examples/
│   ├── __init__.py
│   ├── example_1_basic.py       # Basic conversation example
│   ├── example_2_interrupt.py   # Interrupt handling example
│   ├── example_3_validation.py  # Validation loop example
│   └── example_4_comprehensive.py # All features combined
├── main.py                      # CLI interface
├── requirements.txt             # Python dependencies
├── .env.example                 # Environment variables template
├── .gitignore
└── README.md                    # This file
```

## 🔧 Configuration

Configuration is managed through environment variables in `.env`:

- `OPENAI_API_KEY` (required): Your OpenAI API key
- `TAVILY_API_KEY` (optional): Tavily search API key
- `LLM_MODEL` (optional): OpenAI model to use (default: gpt-4)
- `LLM_TEMPERATURE` (optional): Temperature setting (default: 0.7)

Additional configuration in `src/utils/config.py`:
- `MAX_VALIDATION_ATTEMPTS`: Maximum research-validation loops (default: 3)
- `CONFIDENCE_THRESHOLD`: Confidence score threshold for skipping validation (default: 6.0)

## 🎓 Key Features Demonstrated

### ✅ Required Features (All Implemented)

1. **4 Specialized Agents**
   - ✅ Clarity Agent with status setting and routing
   - ✅ Research Agent with confidence scoring
   - ✅ Validator Agent with quality assessment
   - ✅ Synthesis Agent with response generation

2. **Multi-turn Conversation**
   - ✅ Conversation history maintained via MemorySaver
   - ✅ Context-aware follow-up questions
   - ✅ Thread-based session management

3. **Human-in-the-Loop**
   - ✅ Interrupt mechanism for unclear queries
   - ✅ Request clarification from user
   - ✅ Resume processing after clarification

4. **State Management**
   - ✅ Comprehensive state schema with all required fields
   - ✅ State persistence across conversation turns
   - ✅ Proper state updates at each agent

5. **Conditional Routing**
   - ✅ 3 routing functions (after Clarity, Research, Validator)
   - ✅ Feedback loop from Validator to Research
   - ✅ Attempt counter to prevent infinite loops

6. **Example Demonstrations**
   - ✅ 4 comprehensive example scripts
   - ✅ Shows all major features in action
   - ✅ Clear output demonstrating agent flow

## 🚀 Beyond Expected Deliverable

This implementation includes several enhancements beyond the basic requirements:

### 1. **Dual Data Source Support**
- **Tavily API Integration**: Real-time web search capability when API key is provided
- **Graceful Fallback**: Automatic fallback to mock data if Tavily is unavailable
- **Extended Mock Dataset**: 8 companies with comprehensive information (vs. 2 required)

### 2. **Enhanced Agent Intelligence**
- **Context-Aware Processing**: All agents access conversation history for context
- **Intelligent Company Extraction**: Clarity Agent uses LLM to extract company names from natural language
- **Dynamic Confidence Scoring**: Research Agent provides detailed confidence reasoning
- **Smart Validation**: Validator Agent gives specific feedback on what's missing

### 3. **Production-Ready Architecture**
- **Object-Oriented Design**: Clean class hierarchy with BaseAgent abstraction
- **Modular Structure**: Separate packages for agents, graph, models, and utilities
- **Configuration Management**: Centralized config with validation
- **Error Handling**: Graceful error handling with informative messages

### 4. **Developer Experience**
- **Multiple Usage Modes**: CLI, programmatic API, and example scripts
- **Streaming Support**: Real-time agent execution updates
- **State Inspection**: Methods to inspect current graph state
- **Comprehensive Logging**: Agent activity logging for debugging

### 5. **Documentation & Examples**
- **4 Progressive Examples**: From basic to comprehensive demonstrations
- **Inline Documentation**: Comprehensive docstrings throughout codebase
- **Architecture Diagrams**: Clear ASCII diagrams showing agent flow
- **Usage Examples**: Multiple ways to interact with the system

### 6. **Flexible Conversation Management**
- **Thread-Based Sessions**: Multiple independent conversation threads
- **State Persistence**: Full conversation state maintained across queries
- **State Updates**: Ability to update state mid-conversation (for interrupts)

### 7. **Enhanced Mock Data**
- **Realistic Company Profiles**: Detailed information for 8 major tech companies
- **Multiple Data Points**: News, financials, leadership, developments, history
- **Fuzzy Matching**: Intelligent company name matching (case-insensitive, partial matches)

### 8. **Testing & Quality**
- **Type Annotations**: Full typing throughout the codebase
- **Clean Code**: Follows Python best practices and PEP 8
- **Separation of Concerns**: Clear separation between agents, graph, and utilities
- **Reusable Components**: Base classes and utilities for extensibility

### 9. **Advanced Routing Logic**
- **Confidence-Based Routing**: Skips validation for high-confidence research
- **Attempt Limiting**: Prevents infinite loops with max attempt counter
- **Multi-Path Routing**: Different paths based on multiple conditions

### 10. **User Experience Enhancements**
- **Clear Status Messages**: Informative messages at each step
- **Progress Indication**: Real-time updates on agent execution
- **Graceful Interrupts**: Smooth handling of clarification requests
- **Error Recovery**: Helpful error messages with recovery suggestions

## 🧪 Assumptions Made

1. **LLM Provider**: Assumes OpenAI API (ChatGPT) is available. Could be adapted for other providers.

2. **Company Focus**: System is optimized for publicly-traded companies with business information. May not work well for private companies or non-business entities.

3. **English Language**: All queries and responses are in English.

4. **Query Types**: System assumes queries are about company information (news, financials, leadership, etc.). Not designed for other types of research.

5. **Internet Access**: When using Tavily, assumes internet connectivity. Falls back gracefully to mock data if unavailable.

6. **Conversation Scope**: Each conversation thread is independent. No cross-thread context sharing.

7. **Research Depth**: System provides comprehensive overviews rather than deep technical analysis. Suitable for business intelligence, not academic research.

8. **Mock Data Currency**: Mock data represents a snapshot in time (early 2024). Real-time data requires Tavily API.

9. **Clarification Handling**: System requests one clarification per unclear query. If the clarification is still unclear, it will request again.

10. **Performance**: System is optimized for correctness and clarity over raw speed. Each agent makes LLM calls which add latency.

## 🐛 Troubleshooting

### Common Issues

**"OPENAI_API_KEY not found"**
- Solution: Create a `.env` file from `.env.example` and add your OpenAI API key

**Import errors**
- Solution: Ensure you're running from the project root directory and virtual environment is activated

**"No module named 'src'"**
- Solution: Run scripts using `python -m` syntax (e.g., `python -m examples.example_1_basic`)

**Interrupt not working**
- Solution: Ensure you're using the stream API or checking for interrupts with `get_state()`

**Context not maintained**
- Solution: Use the same thread_id in config across queries in a conversation

## 📝 License

This project is provided as-is for educational and demonstration purposes.

## 🙏 Acknowledgments

- Built with [LangGraph](https://github.com/langchain-ai/langgraph) for multi-agent orchestration
- Uses [LangChain](https://github.com/langchain-ai/langchain) for LLM integration
- Optional integration with [Tavily](https://tavily.com/) for real-time search

---

**Questions or Issues?** Check the example scripts in the `examples/` directory for reference implementations.
