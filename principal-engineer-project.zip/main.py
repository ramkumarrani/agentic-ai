"""
Main CLI interface for the research assistant.
"""
from langchain_core.messages import HumanMessage
from src.graph import ResearchAssistantGraph
from src.utils.config import Config


def main():
    """Run the research assistant in CLI mode."""
    # Validate configuration
    Config.validate()
    
    # Initialize the graph
    print("\n🔬 Initializing Multi-Agent Research Assistant...\n")
    assistant = ResearchAssistantGraph()
    
    # Set up conversation config (maintains state across queries)
    config = {"configurable": {"thread_id": "cli_session"}}
    
    print("=" * 70)
    print("Multi-Agent Research Assistant")
    print("Ask me about any company! Type 'quit' or 'exit' to stop.")
    print("=" * 70)
    
    while True:
        try:
            # Get user input
            user_query = input("\n🧑 You: ").strip()
            
            if not user_query:
                continue
            
            if user_query.lower() in ['quit', 'exit', 'q']:
                print("\n👋 Goodbye!")
                break
            
            # Process the query
            print("\n🤖 Assistant: Processing your query...\n")
            
            # Stream the execution
            for i, update in enumerate(assistant.stream(user_query, config)):
                # Print agent updates
                for node_name, node_output in update.items():
                    if node_name != "__interrupt__":
                        print(f"   [{node_name}] Working...")
            
            # Check if we hit an interrupt (needs clarification)
            state = assistant.get_state(config)
            
            if state.next and "human_clarification" in state.next:
                # Need clarification
                print("\n❓ I need clarification to proceed.")
                
                # Get the last AI message for context
                if state.values.get("messages"):
                    last_msg = state.values["messages"][-1]
                    if hasattr(last_msg, "content"):
                        print(f"   {last_msg.content}")
                
                # Get clarification from user
                clarification = input("\n🧑 Your clarification: ").strip()
                
                if clarification:
                    # Update the query with clarification and resume
                    assistant.update_state(
                        config,
                        {
                            "query": clarification,
                            "messages": state.values.get("messages", []) + [
                                HumanMessage(content=clarification)
                            ],
                        }
                    )
                    
                    # Resume execution (pass None to continue from checkpoint)
                    for update in assistant.app.stream(None, config):
                        for node_name, node_output in update.items():
                            if node_name != "__interrupt__":
                                print(f"   [{node_name}] Working...")
                    
                    # Get final state
                    state = assistant.get_state(config)
            
            # Display final response
            final_response = state.values.get("final_response", "")
            if final_response:
                print(f"\n{final_response}")
            else:
                print("\n⚠️  Could not generate a response. Please try again.")
        
        except KeyboardInterrupt:
            print("\n\n👋 Goodbye!")
            break
        except Exception as e:
            print(f"\n❌ Error: {e}")
            print("Please try again or type 'quit' to exit.")


if __name__ == "__main__":
    main()
