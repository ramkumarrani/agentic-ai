"""
Quick start script to run all example demonstrations.
"""
import subprocess
import sys


def run_example(example_name, description):
    """Run a single example script."""
    print("\n" + "=" * 70)
    print(f"Running: {description}")
    print("=" * 70)
    
    try:
        result = subprocess.run(
            [sys.executable, "-m", example_name],
            capture_output=False,
            text=True
        )
        
        if result.returncode == 0:
            print(f"\n✓ {description} completed successfully")
            return True
        else:
            print(f"\n✗ {description} failed")
            return False
    
    except Exception as e:
        print(f"\n✗ Error running {description}: {e}")
        return False


def main():
    """Run all examples."""
    print("=" * 70)
    print("Multi-Agent Research Assistant - Example Demonstrations")
    print("=" * 70)
    print("\nThis script will run all example demonstrations sequentially.")
    print("Note: This requires OPENAI_API_KEY to be configured in .env")
    
    input("\nPress Enter to continue or Ctrl+C to cancel...")
    
    examples = [
        ("examples.example_1_basic", "Example 1: Basic Multi-Turn Conversation"),
        ("examples.example_2_interrupt", "Example 2: Human-in-the-Loop Interrupts"),
        ("examples.example_3_validation", "Example 3: Validation Feedback Loop"),
        ("examples.example_4_comprehensive", "Example 4: Comprehensive Demonstration"),
    ]
    
    results = []
    for example_name, description in examples:
        result = run_example(example_name, description)
        results.append((description, result))
        
        # Pause between examples
        if result and example_name != examples[-1][0]:
            input("\nPress Enter to continue to next example...")
    
    # Summary
    print("\n" + "=" * 70)
    print("DEMONSTRATION SUMMARY")
    print("=" * 70)
    
    for description, result in results:
        status = "COMPLETED ✓" if result else "FAILED ✗"
        print(f"{description}: {status}")
    
    all_passed = all(result for _, result in results)
    
    if all_passed:
        print("\n🎉 All demonstrations completed successfully!")
    else:
        print("\n⚠️  Some demonstrations failed. Check the output above.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n👋 Demonstration cancelled by user.")
        sys.exit(0)
