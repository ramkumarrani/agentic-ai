# Extension Guide

## 🚀 How to Extend This System

This guide shows you how to extend and customize the Multi-Agent Research Assistant.

---

## Adding a New Agent

### Step 1: Create Agent Class

Create a new file in `src/agents/`:

```python
# src/agents/my_new_agent.py
from typing import Dict, Any
from langchain_core.messages import AIMessage
from src.agents.base import BaseAgent


class MyNewAgent(BaseAgent):
    """
    My custom agent that does something specific.
    """
    
    def __init__(self):
        system_prompt = """You are a specialized agent that...
        
        Your job is to:
        1. ...
        2. ...
        
        Respond with:
        OUTPUT_FIELD: [value]
        """
        
        super().__init__("MyNewAgent", system_prompt)
    
    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Process state and return updates."""
        self.log("Processing...")
        
        # Get inputs from state
        some_input = state.get("some_field", "")
        
        # Do your processing
        result = self.invoke_llm(f"Process: {some_input}")
        
        # Return state updates
        return {
            "my_output_field": result,
            "messages": [AIMessage(content="Processed!")],
        }
```

### Step 2: Update State Schema

Add your agent's fields to `src/models/state.py`:

```python
class AgentState(TypedDict):
    # ... existing fields ...
    
    # Your new fields
    my_output_field: str
```

### Step 3: Add to Graph

Update `src/graph/research_graph.py`:

```python
from src.agents import MyNewAgent

class ResearchAssistantGraph:
    def __init__(self):
        # ... existing agents ...
        self.my_new_agent = MyNewAgent()
    
    def _build_graph(self):
        workflow = StateGraph(AgentState)
        
        # Add your agent as a node
        workflow.add_node("my_new_agent", self.my_new_agent)
        
        # Add edges to/from your agent
        workflow.add_edge("some_agent", "my_new_agent")
        workflow.add_edge("my_new_agent", "another_agent")
```

### Step 4: Update Package

Add to `src/agents/__init__.py`:

```python
from .my_new_agent import MyNewAgent

__all__ = [
    # ... existing ...
    "MyNewAgent",
]
```

---

## Adding a New Routing Function

### Example: Route Based on Custom Logic

In `src/graph/research_graph.py`:

```python
def _route_after_my_agent(self, state: AgentState) -> Literal["path_a", "path_b"]:
    """
    Custom routing logic based on your criteria.
    
    Args:
        state: Current agent state
        
    Returns:
        Next node to visit
    """
    my_value = state.get("my_output_field", "")
    
    if some_condition(my_value):
        return "path_a"
    else:
        return "path_b"

# Add conditional edge
workflow.add_conditional_edges(
    "my_new_agent",
    self._route_after_my_agent,
    {
        "path_a": "agent_a",
        "path_b": "agent_b",
    }
)
```

---

## Adding More Mock Companies

In `src/utils/mock_data.py`:

```python
MOCK_RESEARCH_DATA = {
    # ... existing companies ...
    
    "Your Company": {
        "recent_news": "Latest news about the company...",
        "stock_info": "Stock price and market info...",
        "key_developments": "Recent developments...",
        "ceo": "CEO Name",
        "headquarters": "Location",
        "founded": "Year",
        # Add any custom fields
        "custom_field": "Custom data",
    },
}
```

---

## Adding a New Data Source

### Example: Add Wikipedia Integration

Create `src/utils/wikipedia_search.py`:

```python
import wikipedia


def search_wikipedia(company_name: str) -> dict:
    """
    Search Wikipedia for company information.
    
    Args:
        company_name: Company to search
        
    Returns:
        Wikipedia summary and data
    """
    try:
        summary = wikipedia.summary(company_name, sentences=5)
        page = wikipedia.page(company_name)
        
        return {
            "source": "wikipedia",
            "summary": summary,
            "url": page.url,
            "content": page.content[:1000],
        }
    except Exception as e:
        return {
            "source": "wikipedia",
            "error": str(e)
        }
```

Update `src/agents/research_agent.py`:

```python
from src.utils.wikipedia_search import search_wikipedia

class ResearchAgent(BaseAgent):
    def __call__(self, state):
        # ... existing code ...
        
        # Add Wikipedia search
        wiki_data = search_wikipedia(company_name)
        
        # Combine with existing research
        research_data = {
            "tavily": tavily_data,
            "wikipedia": wiki_data,
            "mock": mock_data,
        }
```

---

## Adding a New Configuration Parameter

In `src/utils/config.py`:

```python
class Config:
    # ... existing ...
    
    # Your new config
    MY_NEW_SETTING = os.getenv("MY_NEW_SETTING", "default_value")
    MY_THRESHOLD = float(os.getenv("MY_THRESHOLD", "0.5"))
```

In `.env.example`:

```bash
# Your new setting (optional)
MY_NEW_SETTING=some_value
MY_THRESHOLD=0.5
```

---

## Adding a New Example

Create `examples/example_5_my_feature.py`:

```python
"""
Example 5: Demonstrating my custom feature.
"""
from src.graph import ResearchAssistantGraph
from src.utils.config import Config


def example_my_feature():
    """
    Example showing:
    - My custom feature
    - How it works
    - Expected outcomes
    """
    print("\n" + "=" * 70)
    print("EXAMPLE 5: My Custom Feature")
    print("=" * 70)
    
    # Initialize
    Config.validate()
    assistant = ResearchAssistantGraph()
    config = {"configurable": {"thread_id": "example_5"}}
    
    # Demonstrate your feature
    query = "Your test query"
    print(f"User: {query}")
    
    result = assistant.invoke(query, config)
    print(f"\nAssistant: {result['final_response']}")
    
    print("\n" + "=" * 70)


if __name__ == "__main__":
    example_my_feature()
```

---

## Creating a Custom Workflow

### Example: Parallel Research

```python
# src/graph/parallel_research_graph.py
from langgraph.graph import StateGraph

class ParallelResearchGraph:
    """
    Custom graph that researches multiple companies in parallel.
    """
    
    def _build_graph(self):
        workflow = StateGraph(AgentState)
        
        # Add multiple research agents
        workflow.add_node("research_agent_1", self.research_agent)
        workflow.add_node("research_agent_2", self.research_agent)
        
        # Parallel branches
        workflow.set_entry_point("clarity_agent")
        workflow.add_edge("clarity_agent", "research_agent_1")
        workflow.add_edge("clarity_agent", "research_agent_2")
        
        # Merge results
        workflow.add_node("merge_results", self._merge_results)
        workflow.add_edge("research_agent_1", "merge_results")
        workflow.add_edge("research_agent_2", "merge_results")
        
        return workflow
    
    def _merge_results(self, state):
        """Merge parallel research results."""
        # Your merging logic
        pass
```

---

## Enhancing Existing Agents

### Example: Add Sentiment Analysis to Research Agent

```python
# src/agents/research_agent.py
from transformers import pipeline  # Add to requirements.txt

class ResearchAgent(BaseAgent):
    def __init__(self):
        super().__init__(...)
        
        # Add sentiment analyzer
        self.sentiment_analyzer = pipeline("sentiment-analysis")
    
    def __call__(self, state):
        # ... existing research ...
        
        # Add sentiment analysis
        news = research_data.get("recent_news", "")
        sentiment = self.sentiment_analyzer(news)[0]
        
        research_data["sentiment"] = {
            "label": sentiment["label"],
            "score": sentiment["score"]
        }
        
        return {
            "research_findings": research_data,
            # ... rest of return ...
        }
```

---

## Adding Visualization

### Example: Create Charts from Data

Create `src/utils/visualization.py`:

```python
import matplotlib.pyplot as plt
import io
import base64


def create_stock_chart(data: dict) -> str:
    """
    Create a stock price chart.
    
    Returns:
        Base64 encoded PNG image
    """
    # Create chart
    fig, ax = plt.subplots()
    ax.plot(data["dates"], data["prices"])
    ax.set_title(f"{data['company']} Stock Price")
    ax.set_xlabel("Date")
    ax.set_ylabel("Price ($)")
    
    # Convert to base64
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_base64 = base64.b64encode(buffer.read()).decode()
    
    return f"data:image/png;base64,{image_base64}"
```

---

## Adding Caching

### Example: Cache Research Results

Create `src/utils/cache.py`:

```python
from functools import lru_cache
import time


class ResearchCache:
    """Simple in-memory cache for research results."""
    
    def __init__(self, ttl_seconds=3600):
        self.cache = {}
        self.ttl = ttl_seconds
    
    def get(self, key: str):
        """Get cached result if not expired."""
        if key in self.cache:
            data, timestamp = self.cache[key]
            if time.time() - timestamp < self.ttl:
                return data
            else:
                del self.cache[key]
        return None
    
    def set(self, key: str, value):
        """Cache a result."""
        self.cache[key] = (value, time.time())


# Global cache instance
research_cache = ResearchCache()
```

Use in Research Agent:

```python
from src.utils.cache import research_cache

class ResearchAgent(BaseAgent):
    def __call__(self, state):
        company_name = state["company_name"]
        
        # Check cache first
        cached = research_cache.get(company_name)
        if cached:
            self.log("Using cached research")
            return cached
        
        # Do research
        result = self._do_research(company_name)
        
        # Cache result
        research_cache.set(company_name, result)
        
        return result
```

---

## Adding Tests

### Example: Unit Test for Clarity Agent

Create `tests/test_clarity_agent.py`:

```python
import pytest
from src.agents import ClarityAgent


def test_clarity_agent_clear_query():
    """Test that clarity agent identifies clear queries."""
    agent = ClarityAgent()
    
    state = {
        "query": "Tell me about Apple",
        "messages": []
    }
    
    result = agent(state)
    
    assert result["clarity_status"] == "clear"
    assert "Apple" in result["company_name"]


def test_clarity_agent_unclear_query():
    """Test that clarity agent identifies unclear queries."""
    agent = ClarityAgent()
    
    state = {
        "query": "What's the stock price?",
        "messages": []
    }
    
    result = agent(state)
    
    assert result["clarity_status"] == "needs_clarification"
```

Run tests:
```bash
pytest tests/
```

---

## Creating a Web Interface

### Example: Streamlit UI

Create `app.py`:

```python
import streamlit as st
from src.graph import ResearchAssistantGraph
from src.utils.config import Config

# Initialize
Config.validate()
assistant = ResearchAssistantGraph()

# Streamlit UI
st.title("🔬 Multi-Agent Research Assistant")

# Session state for conversation
if "thread_id" not in st.session_state:
    st.session_state.thread_id = "streamlit_session"
if "messages" not in st.session_state:
    st.session_state.messages = []

# Display chat history
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.write(msg["content"])

# Chat input
if query := st.chat_input("Ask about a company..."):
    # Add user message
    st.session_state.messages.append({"role": "user", "content": query})
    
    with st.chat_message("user"):
        st.write(query)
    
    # Get response
    config = {"configurable": {"thread_id": st.session_state.thread_id}}
    result = assistant.invoke(query, config)
    
    # Add assistant message
    response = result["final_response"]
    st.session_state.messages.append({"role": "assistant", "content": response})
    
    with st.chat_message("assistant"):
        st.write(response)
```

Run:
```bash
streamlit run app.py
```

---

## Best Practices for Extensions

### 1. Follow Existing Patterns
- Extend `BaseAgent` for new agents
- Use TypedDict for state updates
- Add docstrings for all public methods

### 2. Maintain Type Safety
- Use type hints everywhere
- Keep state schema updated
- Validate inputs and outputs

### 3. Handle Errors Gracefully
```python
try:
    result = risky_operation()
except Exception as e:
    self.log(f"Error: {e}")
    return default_value
```

### 4. Document Your Changes
- Update README.md
- Add docstrings
- Create example scripts
- Update ARCHITECTURE.md if needed

### 5. Test Thoroughly
- Write unit tests
- Create integration tests
- Add example demonstrations
- Test edge cases

---

## Common Extension Scenarios

### Scenario 1: Add Industry Analysis
**Files to modify:**
- `src/agents/industry_agent.py` (new)
- `src/models/state.py` (add industry fields)
- `src/graph/research_graph.py` (add agent and routing)

### Scenario 2: Add Competitor Comparison
**Files to modify:**
- `src/agents/comparison_agent.py` (new)
- `src/utils/mock_data.py` (add competitor data)
- `src/graph/research_graph.py` (add parallel research)

### Scenario 3: Add Export to PDF
**Files to modify:**
- `src/utils/export.py` (new)
- `src/agents/synthesis_agent.py` (add export option)
- `requirements.txt` (add reportlab)

### Scenario 4: Add Real-time Alerts
**Files to modify:**
- `src/utils/alerts.py` (new)
- `src/agents/research_agent.py` (add alert checks)
- `src/utils/config.py` (add alert thresholds)

---

## Getting Help

If you're extending the system and need help:

1. **Check existing code**: Look at similar implementations
2. **Review architecture**: See ARCHITECTURE.md
3. **Read docstrings**: Most functions are documented
4. **Run examples**: See how features work
5. **Test incrementally**: Make small changes and test

---

## Contributing Back

If you create useful extensions:

1. Document them well
2. Add tests
3. Create examples
4. Update documentation
5. Consider sharing with the community

---

Happy extending! 🚀
