"""
LangGraph implementation for multi-agent research assistant.
Connects all agents with conditional routing and state management.
"""
from typing import Literal
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver
from src.models.state import AgentState
from src.agents import ClarityAgent, ResearchAgent, ValidatorAgent, SynthesisAgent
from src.utils.config import Config


class ResearchAssistantGraph:
    """
    Multi-agent research assistant using LangGraph.
    Orchestrates Clarity, Research, Validator, and Synthesis agents.
    """
    
    def __init__(self):
        """Initialize the research assistant graph."""
        self.clarity_agent = ClarityAgent()
        self.research_agent = ResearchAgent()
        self.validator_agent = ValidatorAgent()
        self.synthesis_agent = SynthesisAgent()
        
        # Build the graph
        self.graph = self._build_graph()
        self.app = self.graph.compile(
            checkpointer=MemorySaver(),  # Enable memory for multi-turn conversations
            interrupt_before=["human_clarification"]  # Interrupt for human input
        )
    
    def _build_graph(self) -> StateGraph:
        """
        Build the LangGraph with all agents and routing logic.
        
        Returns:
            Compiled StateGraph
        """
        # Create the graph
        workflow = StateGraph(AgentState)
        
        # Add agent nodes
        workflow.add_node("clarity_agent", self.clarity_agent)
        workflow.add_node("research_agent", self.research_agent)
        workflow.add_node("validator_agent", self.validator_agent)
        workflow.add_node("synthesis_agent", self.synthesis_agent)
        workflow.add_node("human_clarification", self._human_clarification_node)
        
        # Set entry point
        workflow.set_entry_point("clarity_agent")
        
        # Add conditional edges
        workflow.add_conditional_edges(
            "clarity_agent",
            self._route_after_clarity,
            {
                "research": "research_agent",
                "clarify": "human_clarification",
            }
        )
        
        workflow.add_conditional_edges(
            "research_agent",
            self._route_after_research,
            {
                "validate": "validator_agent",
                "synthesize": "synthesis_agent",
            }
        )
        
        workflow.add_conditional_edges(
            "validator_agent",
            self._route_after_validation,
            {
                "research_again": "research_agent",
                "synthesize": "synthesis_agent",
            }
        )
        
        # Synthesis agent always goes to END
        workflow.add_edge("synthesis_agent", END)
        
        # Human clarification loops back to clarity agent
        workflow.add_edge("human_clarification", "clarity_agent")
        
        return workflow
    
    def _route_after_clarity(self, state: AgentState) -> Literal["research", "clarify"]:
        """
        Routing logic after Clarity Agent.
        
        Args:
            state: Current agent state
            
        Returns:
            Next node to visit
        """
        clarity_status = state.get("clarity_status", "needs_clarification")
        
        if clarity_status == "clear":
            return "research"
        else:
            return "clarify"
    
    def _route_after_research(self, state: AgentState) -> Literal["validate", "synthesize"]:
        """
        Routing logic after Research Agent.
        
        Args:
            state: Current agent state
            
        Returns:
            Next node to visit
        """
        confidence_score = state.get("confidence_score", 0)
        
        # If confidence is high, skip validation and go to synthesis
        if confidence_score >= Config.CONFIDENCE_THRESHOLD:
            return "synthesize"
        else:
            return "validate"
    
    def _route_after_validation(self, state: AgentState) -> Literal["research_again", "synthesize"]:
        """
        Routing logic after Validator Agent.
        
        Args:
            state: Current agent state
            
        Returns:
            Next node to visit
        """
        validation_result = state.get("validation_result", "insufficient")
        validation_attempts = state.get("validation_attempts", 0)
        
        # If insufficient and haven't reached max attempts, research again
        if validation_result == "insufficient" and validation_attempts < Config.MAX_VALIDATION_ATTEMPTS:
            return "research_again"
        else:
            # Either sufficient or max attempts reached
            return "synthesize"
    
    def _human_clarification_node(self, state: AgentState) -> dict:
        """
        Placeholder node for human clarification.
        This node will trigger an interrupt in the graph.
        
        Args:
            state: Current agent state
            
        Returns:
            Updated state (unchanged in this case)
        """
        # This node doesn't modify state; it's just a placeholder for the interrupt
        return {}
    
    def invoke(self, query: str, config: dict = None):
        """
        Invoke the graph with a user query.
        
        Args:
            query: User's query
            config: Configuration dict with thread_id for conversation tracking
            
        Returns:
            Final state after processing
        """
        if config is None:
            config = {"configurable": {"thread_id": "default"}}
        
        # Initialize state
        initial_state = {
            "messages": [],
            "query": query,
            "company_name": "",
            "clarity_status": "needs_clarification",
            "research_findings": {},
            "confidence_score": 0.0,
            "validation_result": "insufficient",
            "validation_attempts": 0,
            "final_response": "",
            "next_action": "",
        }
        
        # Run the graph
        result = self.app.invoke(initial_state, config)
        return result
    
    def stream(self, query: str, config: dict = None):
        """
        Stream the graph execution with a user query.
        
        Args:
            query: User's query
            config: Configuration dict with thread_id for conversation tracking
            
        Yields:
            State updates as the graph executes
        """
        if config is None:
            config = {"configurable": {"thread_id": "default"}}
        
        # Initialize state
        initial_state = {
            "messages": [],
            "query": query,
            "company_name": "",
            "clarity_status": "needs_clarification",
            "research_findings": {},
            "confidence_score": 0.0,
            "validation_result": "insufficient",
            "validation_attempts": 0,
            "final_response": "",
            "next_action": "",
        }
        
        # Stream the graph execution
        for update in self.app.stream(initial_state, config):
            yield update
    
    def get_state(self, config: dict):
        """
        Get the current state of the graph.
        
        Args:
            config: Configuration dict with thread_id
            
        Returns:
            Current state
        """
        return self.app.get_state(config)
    
    def update_state(self, config: dict, values: dict):
        """
        Update the state (used for providing clarification after interrupt).
        
        Args:
            config: Configuration dict with thread_id
            values: New values to update in state
        """
        self.app.update_state(config, values)
