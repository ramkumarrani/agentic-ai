"""
Configuration management for the research assistant.
"""
import os
from dotenv import load_dotenv

# Load environment variables
# load_dotenv()
load_dotenv("./../../.env.example")


class Config:
    """Application configuration."""
    
    # API Keys
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
    TAVILY_API_KEY = os.getenv("TAVILY_API_KEY")
    
    # Model settings
    LLM_MODEL = os.getenv("LLM_MODEL", "gpt-4")
    LLM_TEMPERATURE = float(os.getenv("LLM_TEMPERATURE", "0.7"))
    
    # Agent settings
    MAX_VALIDATION_ATTEMPTS = 3
    CONFIDENCE_THRESHOLD = 6.0
    
    # Use Tavily if available
    USE_TAVILY = bool(TAVILY_API_KEY)
    
    @classmethod
    def validate(cls):
        """Validate required configuration."""
        if not cls.OPENAI_API_KEY:
            raise ValueError(
                "OPENAI_API_KEY not found. Please set it in .env file. "
                "Copy .env.example to .env and add your API key."
            )
        
        if cls.USE_TAVILY:
            print("✓ Tavily API key found - will use real-time search")
        else:
            print("ℹ Tavily API key not found - will use mock data")
