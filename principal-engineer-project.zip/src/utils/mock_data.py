"""
Mock data for company research.
Used when Tavily API is not available.
"""

MOCK_RESEARCH_DATA = {
    "Apple Inc.": {
        "recent_news": "Launched Vision Pro mixed reality headset in early 2024, expanding services revenue through Apple TV+ and gaming. Strong iPhone 15 sales in emerging markets.",
        "stock_info": "Trading at $195, up 45% YTD with market cap of $3T",
        "key_developments": "AI integration across product line with Apple Intelligence, new M3 chip architecture, sustainability initiatives with carbon neutral products",
        "ceo": "Tim Cook",
        "headquarters": "Cupertino, California",
        "founded": "1976"
    },
    "Apple": {
        "recent_news": "Launched Vision Pro mixed reality headset in early 2024, expanding services revenue through Apple TV+ and gaming. Strong iPhone 15 sales in emerging markets.",
        "stock_info": "Trading at $195, up 45% YTD with market cap of $3T",
        "key_developments": "AI integration across product line with Apple Intelligence, new M3 chip architecture, sustainability initiatives with carbon neutral products",
        "ceo": "Tim Cook",
        "headquarters": "Cupertino, California",
        "founded": "1976"
    },
    "Tesla": {
        "recent_news": "Cybertruck deliveries ramping up with 50k+ orders fulfilled, energy storage business growing 100% YoY",
        "stock_info": "Trading at $242, volatile quarter with 35% fluctuation",
        "key_developments": "FSD v12 rollout with end-to-end neural network, energy storage growth, Gigafactory expansion in Mexico planned",
        "ceo": "Elon Musk",
        "headquarters": "Austin, Texas",
        "founded": "2003"
    },
    "Microsoft": {
        "recent_news": "Azure AI services gaining market share, GitHub Copilot reaching 1M+ paid subscribers, Gaming division growing with Xbox Game Pass",
        "stock_info": "Trading at $420, up 58% YTD with strong cloud growth",
        "key_developments": "Deep partnership with OpenAI, Copilot integration across Office suite, Teams AI features, acquisition of Activision Blizzard completed",
        "ceo": "Satya Nadella",
        "headquarters": "Redmond, Washington",
        "founded": "1975"
    },
    "Google": {
        "recent_news": "Gemini AI model competing with GPT-4, YouTube Premium reaching 100M subscribers, Cloud revenue growth accelerating",
        "stock_info": "Trading at $142, up 52% YTD with strong ad revenue",
        "key_developments": "Bard AI chatbot evolution into Gemini, quantum computing breakthroughs, Pixel 8 series with AI features, Waymo autonomous vehicle expansion",
        "ceo": "Sundar Pichai",
        "headquarters": "Mountain View, California",
        "founded": "1998"
    },
    "Amazon": {
        "recent_news": "AWS maintaining cloud leadership, Prime Video investing in sports content, healthcare expansion with One Medical",
        "stock_info": "Trading at $178, up 48% YTD with strong retail growth",
        "key_developments": "Generative AI services on AWS, Alexa AI upgrades, drone delivery expansion, Project Kuiper satellite internet launch",
        "ceo": "Andy Jassy",
        "headquarters": "Seattle, Washington",
        "founded": "1994"
    },
    "Netflix": {
        "recent_news": "Ad-supported tier gaining traction with 15M+ subscribers, password sharing crackdown boosting revenue, content expansion in international markets",
        "stock_info": "Trading at $485, up 62% YTD with subscriber growth",
        "key_developments": "Gaming expansion with mobile titles, live sports content testing, AI-driven recommendation improvements, production studio investments",
        "ceo": "Ted Sarandos & Greg Peters (Co-CEOs)",
        "headquarters": "Los Gatos, California",
        "founded": "1997"
    },
    "Meta": {
        "recent_news": "Reality Labs losses continuing but Quest 3 showing promise, Threads social app launched to compete with Twitter, AI chatbots rolled out on platforms",
        "stock_info": "Trading at $475, up 185% YTD after 2023 restructuring",
        "key_developments": "Llama 3 open-source AI model, Ray-Ban Meta smart glasses success, metaverse pivot ongoing, efficiency improvements reducing costs",
        "ceo": "Mark Zuckerberg",
        "headquarters": "Menlo Park, California",
        "founded": "2004"
    }
}


def get_mock_research(company_name: str) -> dict:
    """
    Retrieve mock research data for a company.
    
    Args:
        company_name: Name of the company to research
        
    Returns:
        Dictionary with research findings or None if company not found
    """
    # Try exact match first
    if company_name in MOCK_RESEARCH_DATA:
        return MOCK_RESEARCH_DATA[company_name]
    
    # Try case-insensitive search
    for key in MOCK_RESEARCH_DATA.keys():
        if key.lower() == company_name.lower():
            return MOCK_RESEARCH_DATA[key]
    
    # Try partial match
    for key in MOCK_RESEARCH_DATA.keys():
        if company_name.lower() in key.lower() or key.lower() in company_name.lower():
            return MOCK_RESEARCH_DATA[key]
    
    return None
