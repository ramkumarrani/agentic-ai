"""
Research Agent - Gathers company information and assigns confidence scores.
"""
import re
from typing import Dict, Any
from langchain_core.messages import AIMessage
from src.agents.base import BaseAgent
from src.utils.mock_data import get_mock_research
from src.utils.config import Config
from langchain.agents import create_agent
from langchain_mcp_adapters.client import MultiServerMCPClient

## using tavily-mcp server URL for tavily based search
tavily_mcp_url = f"https://mcp.tavily.com/mcp/?tavilyApiKey={Config.TAVILY_API_KEY}"

class ResearchAgent(BaseAgent):
    """
    Agent responsible for gathering company information.
    Uses Tavily API if available, otherwise falls back to mock data.
    """
    
    def __init__(self):
        system_prompt = """You are a Research Agent specializing in company information gathering.
Your job is to:
1. Search for comprehensive information about the specified company
2. Gather recent news, financials, key developments, and leadership information
3. Evaluate the quality and relevance of the information found
4. Assign a confidence score (0-10) based on:
   - Information completeness (0-3 points)
   - Information recency (0-3 points)
   - Relevance to the query (0-4 points)

When presenting findings, structure them clearly with sections:
- Recent News
- Stock/Financial Information
- Key Developments
- Leadership & Company Details

After presenting findings, provide:
CONFIDENCE_SCORE: [0-10]
REASONING: [brief explanation of the score]"""
        
        super().__init__("ResearchAgent", system_prompt)
        
        # Initialize Tavily if available
        self.use_tavily = Config.USE_TAVILY
        if self.use_tavily:
            try:
                from tavily import TavilyClient
                self.tavily_client = TavilyClient(api_key=Config.TAVILY_API_KEY)
                self.log("Tavily API initialized")
            except Exception as e:
                self.log(f"Tavily initialization failed: {e}. Using mock data.")
                self.use_tavily = False
    
    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process the state and gather company research.
        
        Args:
            state: Current agent state
            
        Returns:
            Updated state with research findings
        """
        company_name = state.get("company_name", "")
        query = state.get("query", "")
        messages = state.get("messages", [])
        
        self.log(f"Researching {company_name}...")
        
        # Gather research data
        if self.use_tavily:
            research_data = self._search_tavily(company_name, query)
        else:
            research_data = self._search_mock(company_name)
        
        # Get conversation context
        context = self.format_conversation_context(messages)
        
        # Analyze and score the research
        analysis_prompt = f"""Company: {company_name}
User Query: {query}

Research Data:
{self._format_research_data(research_data)}

{context}

Analyze this research data and provide a comprehensive summary with a confidence score."""
        
        response = self.invoke_llm(analysis_prompt, context)
        
        # Extract confidence score
        confidence_score = self._extract_confidence_score(response)
        
        self.log(f"Research complete. Confidence: {confidence_score}/10")
        
        return {
            "research_findings": research_data,
            "confidence_score": confidence_score,
            "messages": [AIMessage(content=f"Research completed with confidence {confidence_score}/10")],
        }
    
    # def _search_tavily(self, company_name: str, query: str) -> dict:
    #     """
    #     Search using Tavily API.
        
    #     Args:
    #         company_name: Company to research
    #         query: User's original query
            
    #     Returns:
    #         Research findings dictionary
    #     """
    #     try:
    #         search_query = f"{company_name} {query} news financials recent developments"
    #         results = self.tavily_client.search(
    #             query=search_query,
    #             search_depth="advanced",
    #             max_results=5
    #         )
            
    #         # Structure the results
    #         research_data = {
    #             "source": "tavily",
    #             "results": results.get("results", []),
    #             "raw_content": "\n\n".join([
    #                 f"{r.get('title', '')}: {r.get('content', '')}"
    #                 for r in results.get("results", [])
    #             ])
    #         }
            
    #         return research_data
        
    #     except Exception as e:
    #         self.log(f"Tavily search failed: {e}. Falling back to mock data.")
    #         return self._search_mock(company_name)
        
    async def _search_tavily(self, company_names: str, query: str) -> str:
        """Search using Tavily MCP API."""
        try:
            client = MultiServerMCPClient(
                {
                    "tavily": {
                        "transport": "http",
                        "url": tavily_mcp_url,
                    }
                }
            )
            # identify tools supported by Tavily MCP server
            tools = await client.get_tools()

            ## create agent with model and tools
            agent = create_agent(self.llm, tools)

            ## invoke the agent with search query
            search_query = f"{company_name} {query}"
            response = await agent.ainvoke(
                {
                    "messages": [
                        {"role": "system", "content": "You are a helpful assistant."},
                        {"role": "user", "content": search_query}
                    ]
                }
            )
            return response['messages'][-1].content
        
        except Exception as e:
            print(f"[Research Agent] Tavily MCP search error: {e}")
            return f"Error searching: {str(e)}"
    
    def _search_mock(self, company_name: str) -> dict:
        """
        Search using mock data.
        
        Args:
            company_name: Company to research
            
        Returns:
            Research findings dictionary
        """
        data = get_mock_research(company_name)
        
        if data:
            return {
                "source": "mock",
                "company": company_name,
                "data": data
            }
        else:
            return {
                "source": "mock",
                "company": company_name,
                "data": None,
                "error": f"No information found for {company_name}"
            }
    
    def _format_research_data(self, research_data: dict) -> str:
        """
        Format research data for LLM processing.
        
        Args:
            research_data: Raw research data
            
        Returns:
            Formatted string
        """
        if research_data.get("source") == "tavily":
            return research_data.get("raw_content", "No data available")
        
        elif research_data.get("source") == "mock":
            data = research_data.get("data")
            if not data:
                return research_data.get("error", "No data available")
            
            formatted = []
            for key, value in data.items():
                formatted.append(f"{key.replace('_', ' ').title()}: {value}")
            
            return "\n".join(formatted)
        
        return "No data available"
    
    def _extract_confidence_score(self, response: str) -> float:
        """
        Extract confidence score from LLM response.
        
        Args:
            response: LLM response text
            
        Returns:
            Confidence score (0-10)
        """
        # Look for CONFIDENCE_SCORE pattern
        match = re.search(r'CONFIDENCE[_\s]*SCORE[:\s]*(\d+(?:\.\d+)?)', response, re.IGNORECASE)
        
        if match:
            try:
                score = float(match.group(1))
                return max(0.0, min(10.0, score))
            except ValueError:
                pass
        
        # Fallback: default medium confidence for successful search
        return 7.0
