"""
Synthesis Agent - Creates coherent summaries from research findings.
"""
from typing import Dict, Any
from langchain_core.messages import AIMessage
from src.agents.base import BaseAgent


class SynthesisAgent(BaseAgent):
    """
    Agent responsible for synthesizing research into user-friendly responses.
    Creates coherent summaries maintaining conversation context.
    """
    
    def __init__(self):
        system_prompt = """You are a Synthesis Agent responsible for creating clear, 
comprehensive summaries of company research.

Your job is to:
1. Take research findings and create a well-structured, user-friendly response
2. Directly answer the user's original question
3. Maintain conversation context and reference previous exchanges when relevant
4. Format information clearly with appropriate sections and bullet points
5. Highlight the most important and relevant information first
6. Be concise yet comprehensive

Guidelines:
- Start by directly addressing the user's question
- Use clear section headers for different types of information
- Use bullet points for easy scanning
- Include specific data points (numbers, dates, names) when available
- Keep a professional yet conversational tone
- If information is limited, acknowledge this honestly
- End with an invitation for follow-up questions

Format your response to be immediately useful to the user."""
        
        super().__init__("SynthesisAgent", system_prompt)
    
    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process the state and synthesize final response.
        
        Args:
            state: Current agent state
            
        Returns:
            Updated state with synthesized response
        """
        company_name = state.get("company_name", "")
        query = state.get("query", "")
        research_findings = state.get("research_findings", {})
        confidence_score = state.get("confidence_score", 0)
        messages = state.get("messages", [])
        
        self.log(f"Synthesizing response for {company_name}...")
        
        # Get conversation context
        context = self.format_conversation_context(messages)
        
        # Prepare synthesis prompt
        synthesis_prompt = f"""User Query: {query}
Company: {company_name}
Research Confidence: {confidence_score}/10

Research Findings:
{self._format_research(research_findings)}

{context}

Create a comprehensive, user-friendly response that directly answers the user's question."""
        
        response = self.invoke_llm(synthesis_prompt, context)
        
        self.log("Synthesis complete")
        
        return {
            "final_response": response,
            "messages": [AIMessage(content=response)],
        }
    
    def _format_research(self, research_findings: dict) -> str:
        """
        Format research findings for synthesis.
        
        Args:
            research_findings: Research data
            
        Returns:
            Formatted string
        """
        if not research_findings:
            return "No research findings available"
        
        if research_findings.get("source") == "tavily":
            content = research_findings.get("raw_content", "")
            if content:
                return content
            
            # Format individual results
            results = research_findings.get("results", [])
            if results:
                formatted = []
                for r in results:
                    title = r.get("title", "")
                    content = r.get("content", "")
                    if title and content:
                        formatted.append(f"**{title}**\n{content}")
                return "\n\n".join(formatted)
        
        elif research_findings.get("source") == "mock":
            data = research_findings.get("data")
            if not data:
                return research_findings.get("error", "No data available")
            
            formatted = []
            for key, value in data.items():
                formatted.append(f"**{key.replace('_', ' ').title()}**: {value}")
            
            return "\n".join(formatted)
        
        return str(research_findings)
