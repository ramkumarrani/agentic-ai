"""
Clarity Agent - Analyzes query clarity and determines if clarification is needed.
"""
import re
from typing import Dict, Any
from langchain_core.messages import AIMessage
from src.agents.base import BaseAgent


class ClarityAgent(BaseAgent):
    """
    Agent responsible for analyzing query clarity.
    Determines if the user's query is specific enough or needs clarification.
    """
    
    def __init__(self):
        system_prompt = """You are a Clarity Analysis Agent. Your job is to determine if a user's query 
about a company is clear and specific enough to research.

A query is CLEAR if:
- A specific company name is mentioned (e.g., "Apple", "Tesla", "Microsoft")
- The question is actionable even if broad (e.g., "Tell me about Apple")

A query NEEDS CLARIFICATION if:
- No company name is mentioned (e.g., "What's the stock price?")
- The query is too vague to determine which company (e.g., "Tell me about that tech company")
- Multiple possible companies could match (e.g., "The social media company")

Analyze the query and respond with:
1. "CLEAR" or "NEEDS_CLARIFICATION"
2. If CLEAR: Extract the company name
3. If NEEDS_CLARIFICATION: Explain what information is missing

Format your response as:
STATUS: [CLEAR or NEEDS_CLARIFICATION]
COMPANY: [company name if clear, otherwise "UNKNOWN"]
REASON: [brief explanation]"""
        
        super().__init__("ClarityAgent", system_prompt)
    
    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process the state and determine query clarity.
        
        Args:
            state: Current agent state
            
        Returns:
            Updated state with clarity analysis
        """
        self.log("Analyzing query clarity...")
        
        query = state.get("query", "")
        messages = state.get("messages", [])
        
        # Get conversation context
        context = self.format_conversation_context(messages)
        
        # Analyze the query
        analysis_prompt = f"""Analyze this query: "{query}"

{context}

Determine if this query is clear enough to research a specific company."""
        
        response = self.invoke_llm(analysis_prompt, context)
        
        # Parse the response
        clarity_status, company_name, reason = self._parse_response(response)
        
        self.log(f"Status: {clarity_status}, Company: {company_name}")
        
        # Prepare AI message for conversation history
        if clarity_status == "needs_clarification":
            ai_message = AIMessage(content=f"I need clarification: {reason}")
        else:
            ai_message = AIMessage(content=f"Understood. Researching {company_name}...")
        
        return {
            "clarity_status": clarity_status,
            "company_name": company_name,
            "messages": [ai_message],
        }
    
    def _parse_response(self, response: str) -> tuple:
        """
        Parse the LLM response to extract clarity status and company name.
        
        Args:
            response: LLM response text
            
        Returns:
            Tuple of (clarity_status, company_name, reason)
        """
        # Extract STATUS
        status_match = re.search(r'STATUS:\s*(CLEAR|NEEDS_CLARIFICATION)', response, re.IGNORECASE)
        if status_match:
            status = "clear" if "CLEAR" in status_match.group(1).upper() else "needs_clarification"
        else:
            # Fallback: check if "NEEDS_CLARIFICATION" appears in response
            status = "needs_clarification" if "NEEDS_CLARIFICATION" in response.upper() else "clear"
        
        # Extract COMPANY
        company_match = re.search(r'COMPANY:\s*([^\n]+)', response, re.IGNORECASE)
        company_name = company_match.group(1).strip() if company_match else "UNKNOWN"
        
        # Extract REASON
        reason_match = re.search(r'REASON:\s*([^\n]+)', response, re.IGNORECASE)
        reason = reason_match.group(1).strip() if reason_match else "No reason provided"
        
        return status, company_name, reason
