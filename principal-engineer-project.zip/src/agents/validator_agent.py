"""
Validator Agent - Reviews research quality and determines if additional research is needed.
"""
import re
from typing import Dict, Any
from langchain_core.messages import AIMessage
from src.agents.base import BaseAgent
from src.utils.config import Config


class ValidatorAgent(BaseAgent):
    """
    Agent responsible for validating research quality.
    Determines if research is sufficient or if more information is needed.
    """
    
    def __init__(self):
        system_prompt = """You are a Validation Agent responsible for quality assurance of research.
Your job is to:
1. Review the research findings
2. Check if the information adequately answers the user's query
3. Assess completeness, accuracy, and relevance
4. Determine if additional research is needed

Evaluation criteria:
- Does the research directly address the user's question?
- Is the information comprehensive enough?
- Are there significant gaps or missing key details?
- Is the information relevant and up-to-date?

Respond with:
VALIDATION_RESULT: [SUFFICIENT or INSUFFICIENT]
REASONING: [Detailed explanation of your decision]
MISSING_ASPECTS: [If insufficient, list what's missing]
RECOMMENDATIONS: [If insufficient, suggest what additional research should focus on]"""
        
        super().__init__("ValidatorAgent", system_prompt)
    
    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process the state and validate research quality.
        
        Args:
            state: Current agent state
            
        Returns:
            Updated state with validation results
        """
        company_name = state.get("company_name", "")
        query = state.get("query", "")
        research_findings = state.get("research_findings", {})
        confidence_score = state.get("confidence_score", 0)
        validation_attempts = state.get("validation_attempts", 0)
        messages = state.get("messages", [])
        
        # Increment validation attempts
        new_attempts = validation_attempts + 1
        
        self.log(f"Validating research (attempt {new_attempts}/{Config.MAX_VALIDATION_ATTEMPTS})...")
        
        # Get conversation context
        context = self.format_conversation_context(messages)
        
        # Prepare validation prompt
        validation_prompt = f"""User Query: {query}
Company: {company_name}
Research Confidence Score: {confidence_score}/10

Research Findings:
{self._format_findings(research_findings)}

Validation Attempt: {new_attempts}/{Config.MAX_VALIDATION_ATTEMPTS}

{context}

Validate if this research is sufficient to answer the user's query."""
        
        response = self.invoke_llm(validation_prompt, context)
        
        # Parse validation result
        validation_result = self._parse_validation_result(response)
        
        # Override to sufficient if max attempts reached
        if new_attempts >= Config.MAX_VALIDATION_ATTEMPTS and validation_result == "insufficient":
            self.log(f"Max attempts reached. Proceeding with available research.")
            validation_result = "sufficient"
        
        self.log(f"Validation result: {validation_result}")
        
        return {
            "validation_result": validation_result,
            "validation_attempts": new_attempts,
            "messages": [AIMessage(content=f"Validation: {validation_result} (attempt {new_attempts})")],
        }
    
    def _format_findings(self, research_findings: dict) -> str:
        """
        Format research findings for validation.
        
        Args:
            research_findings: Research data
            
        Returns:
            Formatted string
        """
        if not research_findings:
            return "No research findings available"
        
        if research_findings.get("source") == "tavily":
            return research_findings.get("raw_content", "No content available")
        
        elif research_findings.get("source") == "mock":
            data = research_findings.get("data")
            if not data:
                return research_findings.get("error", "No data available")
            
            formatted = []
            for key, value in data.items():
                formatted.append(f"- {key.replace('_', ' ').title()}: {value}")
            
            return "\n".join(formatted)
        
        return str(research_findings)
    
    def _parse_validation_result(self, response: str) -> str:
        """
        Parse validation result from LLM response.
        
        Args:
            response: LLM response text
            
        Returns:
            "sufficient" or "insufficient"
        """
        # Look for VALIDATION_RESULT pattern
        match = re.search(
            r'VALIDATION[_\s]*RESULT[:\s]*(SUFFICIENT|INSUFFICIENT)',
            response,
            re.IGNORECASE
        )
        
        if match:
            result = match.group(1).lower()
            return "sufficient" if "sufficient" in result else "insufficient"
        
        # Fallback: check for keywords in response
        if "INSUFFICIENT" in response.upper():
            return "insufficient"
        
        # Default to sufficient
        return "sufficient"
