"""
Base agent class for common functionality.
"""
from typing import Dict, Any
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from src.utils.config import Config


class BaseAgent:
    """Base class for all agents with common functionality."""
    
    def __init__(self, name: str, system_prompt: str):
        """
        Initialize the base agent.
        
        Args:
            name: Agent identifier
            system_prompt: System instructions for this agent
        """
        self.name = name
        self.system_prompt = system_prompt
        self.llm = ChatOpenAI(
            model=Config.LLM_MODEL,
            temperature=Config.LLM_TEMPERATURE,
            api_key=Config.OPENAI_API_KEY
        )
    
    def log(self, message: str):
        """Log agent activity."""
        print(f"[{self.name}] {message}")
    
    def format_conversation_context(self, messages: list) -> str:
        """
        Format conversation history for context.
        
        Args:
            messages: List of conversation messages
            
        Returns:
            Formatted conversation history
        """
        if not messages:
            return "No previous conversation."
        
        context = "Previous conversation:\n"
        for msg in messages[-5:]:  # Last 5 messages for context
            if isinstance(msg, HumanMessage):
                context += f"User: {msg.content}\n"
            elif isinstance(msg, AIMessage):
                context += f"Assistant: {msg.content}\n"
        
        return context
    
    def invoke_llm(self, prompt: str, context: str = "") -> str:
        """
        Invoke the LLM with system prompt and user input.
        
        Args:
            prompt: User/agent prompt
            context: Additional context (optional)
            
        Returns:
            LLM response
        """
        messages = [
            SystemMessage(content=self.system_prompt),
        ]
        
        if context:
            messages.append(SystemMessage(content=f"Context: {context}"))
        
        messages.append(HumanMessage(content=prompt))
        
        response = self.llm.invoke(messages)
        return response.content
