"""
State schema for the multi-agent research assistant.
Defines the structure of state passed between agents.
"""
from typing import TypedDict, Annotated, Sequence, Literal
from operator import add
from langchain_core.messages import BaseMessage


class AgentState(TypedDict):
    """
    State schema for the research assistant graph.
    
    Fields:
        messages: Conversation history (list of messages)
        query: Current user query
        company_name: Extracted or clarified company name
        clarity_status: "clear" | "needs_clarification"
        research_findings: Raw research data from Research Agent
        confidence_score: Research confidence (0-10)
        validation_result: "sufficient" | "insufficient"
        validation_attempts: Counter for research-validation loops
        final_response: Synthesized answer for the user
        next_action: Routing decision for conditional edges
    """
    # Conversation context
    messages: Annotated[Sequence[BaseMessage], add]
    query: str
    
    # Company identification
    company_name: str
    
    # Clarity Agent outputs
    clarity_status: Literal["clear", "needs_clarification"]
    
    # Research Agent outputs
    research_findings: dict
    confidence_score: float
    
    # Validator Agent outputs
    validation_result: Literal["sufficient", "insufficient"]
    validation_attempts: int
    
    # Synthesis Agent outputs
    final_response: str
    
    # Routing control
    next_action: str
