# Architecture Documentation

## System Overview

The Multi-Agent Research Assistant is a LangGraph-based system that orchestrates four specialized AI agents to gather and synthesize company information. The system implements human-in-the-loop capabilities, conditional routing, validation feedback loops, and maintains conversation context across multiple turns.

## Core Components

### 1. Agent Layer (`src/agents/`)

#### Base Agent (`base.py`)
- **Purpose**: Provides common functionality for all agents
- **Key Features**:
  - LLM initialization with OpenAI
  - Conversation context formatting
  - Standardized logging
  - LLM invocation wrapper
- **Design Pattern**: Template Method pattern

#### Clarity Agent (`clarity_agent.py`)
- **Responsibility**: Analyze query clarity and extract company names
- **Input**: User query, conversation history
- **Output**: 
  - `clarity_status`: "clear" | "needs_clarification"
  - `company_name`: Extracted company name
- **Routing**:
  - "clear" → Research Agent
  - "needs_clarification" → Interrupt (human-in-the-loop)
- **Algorithm**:
  1. Parse user query with LLM
  2. Check for company name presence
  3. Validate query specificity
  4. Extract company name if clear
  5. Request clarification if unclear

#### Research Agent (`research_agent.py`)
- **Responsibility**: Gather comprehensive company information
- **Input**: Company name, user query, conversation history
- **Output**:
  - `research_findings`: Structured research data
  - `confidence_score`: Float (0-10)
- **Routing**:
  - confidence ≥ 6 → Synthesis Agent
  - confidence < 6 → Validator Agent
- **Data Sources**:
  - Primary: Tavily API (if configured)
  - Fallback: Mock data
- **Confidence Scoring**:
  - Information completeness: 0-3 points
  - Information recency: 0-3 points
  - Query relevance: 0-4 points

#### Validator Agent (`validator_agent.py`)
- **Responsibility**: Assess research quality and completeness
- **Input**: Research findings, confidence score, validation attempts
- **Output**:
  - `validation_result`: "sufficient" | "insufficient"
  - `validation_attempts`: Incremented counter
- **Routing**:
  - "sufficient" → Synthesis Agent
  - "insufficient" AND attempts < 3 → Research Agent (loop)
  - "insufficient" AND attempts ≥ 3 → Synthesis Agent (forced)
- **Validation Criteria**:
  - Does research address user query?
  - Is information comprehensive?
  - Are there significant gaps?
  - Is information relevant and current?

#### Synthesis Agent (`synthesis_agent.py`)
- **Responsibility**: Create user-friendly responses
- **Input**: Research findings, user query, conversation history
- **Output**:
  - `final_response`: Formatted answer
- **Routing**: Always → END
- **Features**:
  - Contextual summarization
  - Structured formatting
  - Key information highlighting
  - Conversational tone

### 2. Graph Layer (`src/graph/`)

#### Research Assistant Graph (`research_graph.py`)
- **Purpose**: Orchestrate multi-agent workflow with LangGraph
- **Key Components**:
  - **StateGraph**: LangGraph workflow definition
  - **MemorySaver**: Checkpoint-based conversation memory
  - **Conditional Edges**: Dynamic routing between agents
  - **Interrupt Points**: Human-in-the-loop mechanism

##### Graph Structure
```
Entry Point: clarity_agent

Nodes:
- clarity_agent
- research_agent
- validator_agent
- synthesis_agent
- human_clarification (interrupt node)

Conditional Edges:
1. clarity_agent → [research_agent | human_clarification]
2. research_agent → [validator_agent | synthesis_agent]
3. validator_agent → [research_agent | synthesis_agent]

Regular Edges:
- human_clarification → clarity_agent
- synthesis_agent → END
```

##### Routing Functions

**`_route_after_clarity(state)`**
```python
if state['clarity_status'] == 'clear':
    return 'research'
else:
    return 'clarify'
```

**`_route_after_research(state)`**
```python
if state['confidence_score'] >= CONFIDENCE_THRESHOLD:
    return 'synthesize'
else:
    return 'validate'
```

**`_route_after_validation(state)`**
```python
if state['validation_result'] == 'insufficient' and \
   state['validation_attempts'] < MAX_VALIDATION_ATTEMPTS:
    return 'research_again'
else:
    return 'synthesize'
```

### 3. State Management (`src/models/`)

#### Agent State Schema (`state.py`)

```python
AgentState = TypedDict {
    # Conversation management
    messages: Annotated[Sequence[BaseMessage], add]
    query: str
    
    # Company identification
    company_name: str
    
    # Clarity Agent outputs
    clarity_status: Literal["clear", "needs_clarification"]
    
    # Research Agent outputs
    research_findings: dict
    confidence_score: float
    
    # Validator Agent outputs
    validation_result: Literal["sufficient", "insufficient"]
    validation_attempts: int
    
    # Synthesis Agent outputs
    final_response: str
    
    # Routing control
    next_action: str
}
```

**State Flow**:
1. Initial state created with user query
2. Each agent reads relevant fields
3. Each agent updates specific fields
4. State persists via MemorySaver
5. State accumulates across conversation turns

### 4. Utilities (`src/utils/`)

#### Configuration (`config.py`)
- Environment variable management
- API key validation
- Model settings
- System parameters (thresholds, max attempts)

#### Mock Data (`mock_data.py`)
- Company information database
- Fuzzy matching for company names
- Fallback when Tavily unavailable

## Data Flow

### Successful Clear Query Flow

```
1. User Query: "Tell me about Apple"
   ↓
2. Clarity Agent
   - Analyzes: "Apple" is clear
   - Sets: clarity_status = "clear"
   - Extracts: company_name = "Apple"
   ↓
3. Research Agent
   - Searches: Apple information
   - Scores: confidence = 8/10
   - Stores: research_findings
   ↓
4. Synthesis Agent (high confidence, skip validation)
   - Formats: Research into response
   - Creates: final_response
   ↓
5. Return to User
```

### Unclear Query with Interrupt Flow

```
1. User Query: "What's the stock price?"
   ↓
2. Clarity Agent
   - Analyzes: No company mentioned
   - Sets: clarity_status = "needs_clarification"
   ↓
3. Human Clarification Node (INTERRUPT)
   - Workflow pauses
   - System requests clarification
   ↓
4. User Clarification: "Tesla"
   ↓
5. State Updated with clarification
   ↓
6. Clarity Agent (resumed)
   - Analyzes: "Tesla" is clear
   - Sets: clarity_status = "clear"
   ↓
7. Continue with Research Agent...
```

### Low Confidence with Validation Loop Flow

```
1. Research Agent
   - Searches company info
   - Scores: confidence = 4/10
   ↓
2. Validator Agent (attempt 1)
   - Evaluates: Insufficient
   - Sets: validation_result = "insufficient"
   - Increments: validation_attempts = 1
   ↓
3. Research Agent (loop back)
   - Re-searches with context
   - Scores: confidence = 5/10
   ↓
4. Validator Agent (attempt 2)
   - Evaluates: Insufficient
   - Increments: validation_attempts = 2
   ↓
5. Research Agent (loop back)
   - Third attempt
   ↓
6. Validator Agent (attempt 3)
   - Max attempts reached
   - Forces: validation_result = "sufficient"
   ↓
7. Synthesis Agent
   - Proceeds with available data
```

## Design Patterns

### 1. Template Method Pattern
- **Where**: BaseAgent class
- **Why**: Common functionality across all agents
- **Benefit**: Code reuse, consistent behavior

### 2. Strategy Pattern
- **Where**: Routing functions
- **Why**: Different routing logic based on state
- **Benefit**: Flexible routing, easy to modify

### 3. State Pattern
- **Where**: AgentState TypedDict
- **Why**: Complex state management across agents
- **Benefit**: Type safety, clear state structure

### 4. Chain of Responsibility
- **Where**: Agent workflow
- **Why**: Each agent handles specific responsibility
- **Benefit**: Separation of concerns, modularity

## Scalability Considerations

### Horizontal Scaling
- Each conversation thread is independent
- Multiple threads can run concurrently
- Stateless agents (state passed as parameter)

### Vertical Scaling
- Agents are CPU-bound (LLM calls)
- Can increase LLM capacity
- Can parallelize independent operations

### Extensibility
- Add new agents by extending BaseAgent
- Add new routing logic via conditional edges
- Extend state schema with new fields
- Plug in different LLMs via LangChain

## Performance Characteristics

### Time Complexity
- Per query: O(n) where n = number of agents executed
- With validation loop: O(3n) worst case
- With interrupt: O(n + 1) after clarification

### Space Complexity
- State size: O(m) where m = message history length
- Memory usage: O(k) where k = number of concurrent threads

### Latency Sources
1. LLM API calls (dominant factor)
2. Tavily API calls (if enabled)
3. State serialization (minimal)
4. Routing logic (negligible)

## Security Considerations

### API Key Management
- Environment variables only
- Never hardcoded
- .env excluded from version control

### Input Validation
- Query sanitization via LLM
- No direct code execution
- No SQL injection risk (no database)

### Output Sanitization
- LLM-generated content only
- No user-provided code execution
- Rate limiting via API provider

## Error Handling

### Agent Failures
- Try-except blocks in agent calls
- Graceful fallback to default values
- Error logging for debugging

### API Failures
- Tavily fallback to mock data
- OpenAI retry with exponential backoff
- Informative error messages to user

### State Corruption
- State validation on updates
- Type checking via TypedDict
- Recovery via state inspection

## Testing Strategy

### Unit Tests
- Individual agent logic
- Routing function correctness
- State schema validation
- Mock data retrieval

### Integration Tests
- Full workflow execution
- Interrupt handling
- Validation loops
- Multi-turn conversations

### Example Scripts
- Serve as integration tests
- Demonstrate all features
- Verify end-to-end flow

## Future Enhancements

### Potential Additions
1. **Caching Layer**: Cache research results
2. **Parallel Research**: Multiple sources simultaneously
3. **Advanced Analytics**: Sentiment analysis, trend detection
4. **Multi-Company**: Compare multiple companies
5. **Visualization**: Charts and graphs
6. **Export**: PDF, JSON export of results
7. **RAG Integration**: Knowledge base with embeddings
8. **Streaming Responses**: Real-time token streaming
9. **Custom Agents**: User-defined specialized agents
10. **Metrics Dashboard**: Usage analytics and performance

### Optimization Opportunities
1. Reduce LLM calls via caching
2. Batch processing for multiple queries
3. Parallel agent execution where possible
4. Streaming for better user experience
5. Smarter validation to reduce loops

---

**Document Version**: 1.0
**Last Updated**: January 2026
**Status**: Complete and Production-Ready
