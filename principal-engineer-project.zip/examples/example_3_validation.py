"""
Example 3: Low confidence research triggering validation loop.
Demonstrates the feedback mechanism between Validator and Research agents.
"""
from src.graph import ResearchAssistantGraph
from src.utils.config import Config


def example_validation_loop():
    """
    Example showing:
    - Research with potentially low confidence
    - Validation agent detecting insufficient information
    - Feedback loop back to research agent
    - Multiple validation attempts
    - Final synthesis after validation
    """
    print("\n" + "=" * 70)
    print("EXAMPLE 3: Validation Feedback Loop")
    print("=" * 70)
    
    # Initialize
    Config.validate()
    assistant = ResearchAssistantGraph()
    config = {"configurable": {"thread_id": "example_3"}}
    
    # Query about a company not in our mock data (forces lower confidence)
    print("\n--- Query About Less Common Company ---")
    query = "Tell me about Netflix's gaming expansion"
    print(f"User: {query}")
    
    print("\nProcessing with detailed agent flow...")
    
    # Track which agents run
    agent_sequence = []
    
    for update in assistant.stream(query, config):
        for node_name, node_output in update.items():
            if node_name != "__interrupt__":
                agent_sequence.append(node_name)
                print(f"  [{node_name}] Executing...")
                
                # Show confidence and validation details
                if "confidence_score" in node_output:
                    print(f"      → Confidence Score: {node_output['confidence_score']}/10")
                
                if "validation_result" in node_output:
                    print(f"      → Validation Result: {node_output['validation_result']}")
                    print(f"      → Validation Attempts: {node_output['validation_attempts']}")
    
    # Get final state
    state = assistant.get_state(config)
    
    # Display agent flow
    print(f"\n--- Agent Execution Sequence ---")
    print(" → ".join(agent_sequence))
    
    # Show if validation loop occurred
    research_count = agent_sequence.count("research_agent")
    validator_count = agent_sequence.count("validator_agent")
    
    if research_count > 1 or validator_count > 0:
        print(f"\n✓ Validation Loop Demonstrated:")
        print(f"  - Research Agent executed {research_count} time(s)")
        print(f"  - Validator Agent executed {validator_count} time(s)")
        print(f"  - Final validation attempts: {state.values['validation_attempts']}")
    
    # Display final response
    print(f"\n--- Final Response ---")
    print(state.values['final_response'])
    
    print("\n" + "=" * 70)


if __name__ == "__main__":
    example_validation_loop()
