"""
Example 4: Comprehensive demonstration of all features.
Shows the complete system capabilities in one conversation.
"""
from langchain_core.messages import HumanMessage
from src.graph import ResearchAssistantGraph
from src.utils.config import Config


def example_comprehensive():
    """
    Comprehensive example demonstrating:
    1. Unclear query → Interrupt → Clarification
    2. Clear query with high confidence → Direct synthesis
    3. Follow-up questions with context
    4. Low confidence query → Validation loop
    """
    print("\n" + "=" * 70)
    print("EXAMPLE 4: Comprehensive System Demonstration")
    print("=" * 70)
    
    # Initialize
    Config.validate()
    assistant = ResearchAssistantGraph()
    config = {"configurable": {"thread_id": "example_4"}}
    
    # Scenario 1: Unclear query requiring clarification
    print("\n" + "-" * 70)
    print("SCENARIO 1: Unclear Query → Interrupt & Clarification")
    print("-" * 70)
    
    query1 = "What are the recent developments?"
    print(f"\nUser: {query1}")
    
    for update in assistant.stream(query1, config):
        pass  # Just process
    
    state = assistant.get_state(config)
    
    if state.next and "human_clarification" in state.next:
        print("⚠️  Interrupt triggered - needs clarification")
        clarification = "I meant Microsoft"
        print(f"\nUser (clarification): {clarification}")
        
        assistant.update_state(
            config,
            {
                "query": clarification,
                "messages": state.values.get("messages", []) + [
                    HumanMessage(content=clarification)
                ],
            }
        )
        
        for update in assistant.app.stream(None, config):
            pass
        
        state = assistant.get_state(config)
    
    print(f"\n✓ Response:\n{state.values['final_response'][:200]}...")
    
    # Scenario 2: Clear query with follow-ups
    print("\n" + "-" * 70)
    print("SCENARIO 2: Clear Query with Context-Aware Follow-ups")
    print("-" * 70)
    
    query2 = "Tell me about Amazon"
    print(f"\nUser: {query2}")
    
    result2 = assistant.invoke(query2, config)
    print(f"\n✓ Response:\n{result2['final_response'][:200]}...")
    
    # Follow-up 1
    query3 = "What about their CEO?"
    print(f"\nUser (follow-up): {query3}")
    
    result3 = assistant.invoke(query3, config)
    print(f"\n✓ Response:\n{result3['final_response'][:150]}...")
    
    # Follow-up 2
    query4 = "And their stock price?"
    print(f"\nUser (follow-up): {query4}")
    
    result4 = assistant.invoke(query4, config)
    print(f"\n✓ Response:\n{result4['final_response'][:150]}...")
    
    # Scenario 3: Show system stats
    print("\n" + "-" * 70)
    print("CONVERSATION SUMMARY")
    print("-" * 70)
    
    print(f"Total queries processed: 4")
    print(f"Clarifications requested: 1")
    print(f"Follow-up questions handled: 2")
    print(f"Companies researched: Microsoft, Amazon")
    print(f"Conversation thread: {config['configurable']['thread_id']}")
    
    print("\n" + "=" * 70)


if __name__ == "__main__":
    example_comprehensive()
