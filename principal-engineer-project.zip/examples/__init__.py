"""Examples package."""
