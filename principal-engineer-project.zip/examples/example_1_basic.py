"""
Example 1: Basic multi-turn conversation with clear queries.
Demonstrates the full agent workflow and context maintenance.
"""
from langchain_core.messages import HumanMessage
from src.graph import ResearchAssistantGraph
from src.utils.config import Config


def example_basic_conversation():
    """
    Example showing:
    - Clear initial query
    - Multi-turn conversation with follow-up questions
    - Context maintenance across turns
    """
    print("\n" + "=" * 70)
    print("EXAMPLE 1: Basic Multi-Turn Conversation")
    print("=" * 70)
    
    # Initialize
    Config.validate()
    assistant = ResearchAssistantGraph()
    config = {"configurable": {"thread_id": "example_1"}}
    
    # Turn 1: Initial query about Apple
    print("\n--- Turn 1: Initial Query ---")
    query1 = "Tell me about Apple's recent developments"
    print(f"User: {query1}")
    
    result1 = assistant.invoke(query1, config)
    print(f"\nAssistant: {result1['final_response']}")
    print(f"\n[Metadata] Confidence: {result1['confidence_score']}/10, "
          f"Validation Attempts: {result1['validation_attempts']}")
    
    # Turn 2: Follow-up question (context-dependent)
    print("\n--- Turn 2: Follow-Up Question ---")
    query2 = "What about their stock performance?"
    print(f"User: {query2}")
    
    result2 = assistant.invoke(query2, config)
    print(f"\nAssistant: {result2['final_response']}")
    
    # Turn 3: Another follow-up
    print("\n--- Turn 3: Another Follow-Up ---")
    query3 = "Who is the CEO?"
    print(f"User: {query3}")
    
    result3 = assistant.invoke(query3, config)
    print(f"\nAssistant: {result3['final_response']}")
    
    print("\n" + "=" * 70)


if __name__ == "__main__":
    example_basic_conversation()
