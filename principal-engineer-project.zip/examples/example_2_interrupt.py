"""
Example 2: Human-in-the-loop with unclear query requiring clarification.
Demonstrates the interrupt mechanism when the Clarity Agent detects ambiguity.
"""
from langchain_core.messages import HumanMessage
from src.graph import ResearchAssistantGraph
from src.utils.config import Config


def example_with_interrupts():
    """
    Example showing:
    - Unclear initial query triggering interrupt
    - Human clarification
    - Resumption after clarification
    - Successful completion
    """
    print("\n" + "=" * 70)
    print("EXAMPLE 2: Human-in-the-Loop (Interrupt & Clarification)")
    print("=" * 70)
    
    # Initialize
    Config.validate()
    assistant = ResearchAssistantGraph()
    config = {"configurable": {"thread_id": "example_2"}}
    
    # Initial unclear query
    print("\n--- Initial Query (Unclear) ---")
    query = "What's the stock price?"
    print(f"User: {query}")
    
    # Start processing
    print("\nProcessing...")
    for update in assistant.stream(query, config):
        for node_name in update.keys():
            if node_name != "__interrupt__":
                print(f"  [{node_name}] Working...")
    
    # Check for interrupt
    state = assistant.get_state(config)
    
    if state.next and "human_clarification" in state.next:
        print("\n⚠️  INTERRUPT: Clarity Agent detected unclear query")
        print(f"   Reason: No company name mentioned in the query")
        
        # Simulate human clarification
        print("\n--- Providing Clarification ---")
        clarification = "I meant Tesla"
        print(f"User (clarification): {clarification}")
        
        # Update state with clarification
        assistant.update_state(
            config,
            {
                "query": clarification,
                "messages": state.values.get("messages", []) + [
                    HumanMessage(content=clarification)
                ],
            }
        )
        
        # Resume execution
        print("\nResuming processing...")
        for update in assistant.app.stream(None, config):
            for node_name in update.keys():
                if node_name != "__interrupt__":
                    print(f"  [{node_name}] Working...")
        
        # Get final result
        state = assistant.get_state(config)
        print(f"\nAssistant: {state.values['final_response']}")
    else:
        # No interrupt (shouldn't happen with this example)
        print(f"\nAssistant: {state.values['final_response']}")
    
    print("\n" + "=" * 70)


if __name__ == "__main__":
    example_with_interrupts()
